<?php return array (
  'live-search' => 'App\\Http\\Livewire\\LiveSearch',
);