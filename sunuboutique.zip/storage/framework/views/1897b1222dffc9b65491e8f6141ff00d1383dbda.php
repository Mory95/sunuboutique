    
<?php $__env->startSection('content'); ?>
<div class="antialiased">
    <div class="relative flex items-top justify-center min-h-screen bg-gray-100 dark:bg-gray-900 sm:items-center sm:pt-0">
        <?php if(Route::has('login')): ?>
            <div class="hidden fixed top-0 right-0 px-6 py-4 sm:block">
                <?php if(auth()->guard()->check()): ?>
                
                <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>" class="text-sm text-gray-700 underline">Login</a>

                    <?php if(Route::has('register')): ?>
                        <a href="<?php echo e(route('register')); ?>" class="ml-4 text-sm text-gray-700 underline">Register</a>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <div class="max-w-6xl mx-auto sm:px-6 lg:px-8">
          <div class="row mb-2">
              <?php $__currentLoopData = $prod; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($p->qte_stock>0): ?>
                  <div class="col-md-4">
                    <div class="card mb-4 shadow-sm">
                        <img src="<?php echo e(asset('storage/'.$p->image)); ?>" alt="Image produit" class="bd-placeholder-img card-img-top" style="width: 100%; height: 250px;">
                        <div class="card-body" >
                           
                            <strong class="d-inline-block mb-2">Categorie</strong>                                        
                            <br><strong class="d-inline-block mb-2 text-primary"><?php echo e($p->libelle); ?></strong>
                            <p class="card-text" id="libelle"><?php echo e($p->description); ?></p>
                            <strong class="stretched-link"><?php echo e($p->prix); ?> FCFA</strong>
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="btn-group">
                                    <button type="button" class="btn btn-sm btn-outline-secondary">
                                        <a href="<?php echo e(route('produit.show', $p->id)); ?>" class=" stretched-link" style="text-decoration: none;">
                                            Voire produitss
                                        </a>
                                    </button>
                                    <button type="button" class="btn btn-sm btn btn-primary ml-2">
                                        <a href="<?php echo e(route('cart.store', $p->id )); ?>"class="stretched-link" style="text-decoration: none;">
                                            Ajouter au panier
                                        </a>
                                    </button>
                                </div>
                                <small class="text-muted">9 mins</small>
                            </div>

                                   <!--   <div class="card-footer px-1">
                                        <span class="float-right">
                                        <a data-toggle="tooltip" data-placement="top" title="Add to Cart">
                                            <i class="fas fa-shopping-cart grey-text ml-3"></i>
                                        </a>
                                        <a data-toggle="tooltip" data-placement="top" title="Share">
                                            <i class="fas fa-share-alt grey-text ml-3"></i>
                                        </a>
                                        <a class="active" data-toggle="tooltip" data-placement="top" title="Added to Wishlist">
                                            <i class="fas fa-heart ml-3"></i>
                                        </a>
                                        </span>
                                    </div>  -->
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>







<?php echo $__env->make('layouts.masterLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sunuboutique\resources\views/welcome.blade.php ENDPATH**/ ?>