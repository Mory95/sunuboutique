    
    <?php $__env->startSection('content'); ?>
    
    <?php $__env->startSection('extra-style'); ?>
    <style>
    	.imgs {
    		border: 1px solid #ddd; /* Gray border */
    		border-radius: 4px;  /* Rounded border */
    		padding: 5px; /* Some padding */
    		width: 150px; /* Set a small width */
    	}

    	/* Add a hover effect (blue shadow) */
    	.imgs:hover {
    		box-shadow: 0 0 2px 1px rgba(0, 140, 186, 0.5);
    	}
    </style>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('extra-script'); ?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('content'); ?>

    <div class="product-section container">
    	<div class="row">
            <div>
                <div class="product-section-image" style="height: 450px">
                    <img src="<?php echo e(asset('storage/'.$prod->image)); ?>" id="currentImg" class="active imgs" alt="Image produit" style="width: 100%; height: 100%;">
                </div>
                <div class="product-section-images mt-2">
                    <?php if($prod->images): ?>
                    <div class="product-section-thumbnail imgs" style="display: inline-block">
                        <img src="<?php echo e(asset('storage/'.$prod->image)); ?>"  class="newImg" style="height: 100px; width: 100%;" alt="Image produit">
                    </div>
                    <?php $__currentLoopData = json_decode($prod->images, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="product-section-thumbnail imgs" style="display: inline-block">
                        <img src="<?php echo e(asset('storage/'.$img)); ?>" alt="Image produit"  style="height: 100px; width: 100%;" class="newImg">
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
            <div class=" product-section-information ml-5 mt-3">
                <strong class="d-inline-block mb-2 text-primary product-section-title"><?php echo e($prod->libelle); ?></strong>
                <h3 class="mb-0 product-section-subtitle"><?php echo e($prod->description); ?></h3>
                <strong class="product-section-price"><?php echo e($prod->prix); ?> FCFA</strong>
                <p>
                    <form action="<?php echo e(route('cart.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" value="<?php echo e($prod->id); ?>" name=id>
                        <button type="submit" class="btn btn-dark">Ajouter au panier</button>
                    </form>
                </p>
            </div>
        </div>
    </div>


    <?php $__env->stopSection(); ?>


    <?php $__env->startSection('extra-js'); ?>

    <script>
    	$('.newImg').on('click',  function() {
    		$('#currentImg').prop('src', this.src);
    	});
    </script>

    <script>
    	(function(){
    		const currentImage = document.querySelector('#currentImg');
    		const images = document.querySelectorAll('.product-section-thumbnail');
    		images.forEach((element) => element.addEventListener('click', thumbnailClick));
    		function thumbnailClick(e) {
    			currentImage.classList.remove('active');
    			currentImage.addEventListener('transitionend', () => {
    				currentImage.src = this.querySelector('img').src;
    				currentImage.classList.add('active');
    			})
    			images.forEach((element) => element.classList.remove('selected'));
    			this.classList.add('selected');
    		}
    	})();
    </script>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.testLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sunuboutique\resources\views/produit/show.blade.php ENDPATH**/ ?>