    
    <?php $__env->startSection('extra-style'); ?>
    <link href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css" rel="stylesheet">
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('content'); ?>
    <div class="antialiased">
        <div class="relative flex items-top justify-center min-h-screen bg-gray-100 dark:bg-gray-900 sm:items-center sm:pt-0">

            <div class="max-w-6xl mx-auto sm:px-6 lg:px-8">
                <div class="row mb-2">
                  <?php $__currentLoopData = $prod; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($p->qte_stock>0): ?>
                  <div>
                    <div class="card shadow-sm" style="height: 460px; width: 350px; margin: 5px;">
                        <img src="<?php echo e(asset('storage/'.$p->image)); ?>" alt="Image produit" class="bd-placeholder-img card-img-top imgs" style="width: 100%; height: 250px;">
                        <div class="card-body" >
                            <?php $__currentLoopData = $p->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <strong class="d-inline-block mb-2"><?php echo e($item->name); ?></strong>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <br><strong class="d-inline-block mb-2 text-primary"><?php echo e($p->libelle); ?></strong>
                            <p class="card-text" id="libelle"><?php echo e($p->description); ?></p>
                            <strong class="stretched-link"><?php echo e($p->prix); ?> FCFA</strong>
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="btn-group">
                                    <button type="button" class="btn btn-sm btn-outline-secondary">
                                        <a href="<?php echo e(route('AddProductToCart', $p->id)); ?>" class="stretched-link text-dark" style="text-decoration: none;">
                                            Ajouter au panier
                                        </a>
                                    </button>
                                    <button type="button" class="ml-2 btn btn-sm btn btn-outline-dark">
                                        <a href="<?php echo e(route('produit.show', $p->id)); ?>" class="stretched-link text-dark" style="text-decoration: none;">
                                            Voire produit
                                        </a>
                                    </button>
                                </div>
                                <small class="text-muted">9 mins</small>
                            </div>

                                           <!--   <div class="card-footer px-1">
                                                <span class="float-right">
                                                <a data-toggle="tooltip" data-placement="top" title="Add to Cart">
                                                    <i class="fas fa-shopping-cart grey-text ml-3"></i>
                                                </a>
                                                <a data-toggle="tooltip" data-placement="top" title="Share">
                                                    <i class="fas fa-share-alt grey-text ml-3"></i>
                                                </a>
                                                <a class="active" data-toggle="tooltip" data-placement="top" title="Added to Wishlist">
                                                    <i class="fas fa-heart ml-3"></i>
                                                </a>
                                                </span>
                                            </div>  -->
                                        </div>
                                    </div>
                                </div>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="flex justify-content-center">

                    <?php echo e($prod->appends( request()->input() )->links()); ?>


                </div>
                <?php $__env->stopSection(); ?>  
                <?php $__env->startSection('extra-js'); ?>

                <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
                <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>


                <script>
                   <?php if(Session::has('message')): ?>
                   var type="<?php echo e(Session::get('alert-type','info')); ?>"

                   switch(type){
                     case 'info':
                     toastr.info("<?php echo e(Session::get('message')); ?>");
                     break;
                     case 'success':
                     toastr.success("<?php echo e(Session::get('message')); ?>");
                     break;
                     case 'warning':
                     toastr.warning("<?php echo e(Session::get('message')); ?>");
                     break;
                     case 'error':
                     toastr.error("<?php echo e(Session::get('message')); ?>");
                     break;
                 }
                 <?php endif; ?>
             </script>
             <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.testLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sunuboutique\resources\views/produit/index.blade.php ENDPATH**/ ?>