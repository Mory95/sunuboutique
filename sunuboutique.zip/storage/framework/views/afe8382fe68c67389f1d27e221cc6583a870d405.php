<div class="navbar-form navbar-left ml-3 mt-3">
	
	<form class="navbar-form navbar-left ml-3 mt-3" wire:submit="searchByLibelle">
		<div class="input-group mb-3">
			<input type="text" class="form-control" wire:model="value" placeholder="Search" aria-label="search" aria-describedby="basic-addon2">
			<div class="input-group-append">
				<span class="input-group-text" id="basic-addon2">search</span><?php echo e($value); ?>

			</div>
		</div>
	</form>
</div>
<?php /**PATH C:\xampp\htdocs\sunuboutique\resources\views/livewire/live-search.blade.php ENDPATH**/ ?>