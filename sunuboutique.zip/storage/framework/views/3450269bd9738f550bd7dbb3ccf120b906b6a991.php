
<?php $__env->startSection('extra-style'); ?>
<link href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="px-4 px-lg-0">

  <!-- End -->

  <div class="pb-5">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 p-5 bg-white rounded shadow-sm mb-5">

          <!-- Shopping cart table -->
          <?php if(Cart::count() > 0): ?>
          <div class="table-responsive">
            <table class="table">
              <thead>
                <tr>
                  <th scope="col" class="border-0 bg-light">
                    <div class="p-2 px-3 text-uppercase">Produit</div>
                  </th>
                  <th scope="col" class="border-0 bg-light">
                    <div class="py-2 text-uppercase">Prix</div>
                  </th>
                  <th scope="col" class="border-0 bg-light">
                    <div class="py-2 text-uppercase">Quantité</div>
                  </th>
                  <th scope="col" class="border-0 bg-light">
                    <div class="py-2 text-uppercase">Retirer</div>
                  </th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = Cart::Content (); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <th scope="row">
                    <div class="p-2">
                      <div class="ml-3 d-inline-block align-middle">
                        <h5 class="mb-0"><a href="#" class="text-dark d-inline-block"><?php echo e($prod->model->libelle); ?></a></h5>
                        <img src="<?php echo e(asset('storage/'.$prod->model->image)); ?>" alt="" width="70" class="img-fluid rounded shadow-sm">
                        <span class="text-muted font-weight-normal font-italic">Category: Nom categorie</span>
                      </div>
                    </div>
                    <td class="align-middle"><strong><?php echo e($prod->Subtotal()); ?> FCFA</strong></td>
                    <td class="align-middle">
                      <strong>
                        <form action="<?php echo e(Route('cart.update', $prod->rowId)); ?>" method="POST">
                          <?php echo csrf_field(); ?>
                          <?php echo method_field('PATCH'); ?>
                          <input type="hidden" value="<?php echo e($prod->id); ?>" name="id_prod">
                          <select name="qte" id="qte" data-id="<?php echo e($prod->rowId); ?>" class="custom-select" style="width: 50px">
                            <?php for($i = 1; $i < 7; $i++): ?>
                            <option value="<?php echo e($i); ?>" <?php echo e($i == $prod->qty ? 'selected' : ''); ?>><?php echo e($i); ?></option>
                            <?php endfor; ?>
                          </select>
                          <button type="submit" style="color: orange; border-style: none;">
                            <i class="fa fa-pencil-square fa-lg" aria-hidden="true" style="color: orange;"></i>
                          </button>
                        </form>
                      </strong>
                    </td>
                    <td class="align-middle">
                      <form action="<?php echo e(Route('cart.destroy', $prod->rowId)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit">
                          <i class="fa fa-trash-o fa-lg" style="color: red ;"></i>
                        </button>
                      </form>
                    </td>
                  </th>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
          <!-- End -->

          <div class="row py-5 p-4 bg-white rounded shadow-sm">
            <div class="col-lg-6">
              <div class="bg-light rounded-pill px-4 py-3 text-uppercase font-weight-bold">CODE DE COUPON</div>
              <?php if(!request()->session()->has('coupon')): ?>
              <div class="p-4">
                <p class="font-italic mb-4">Si vous avez un code promo, veuillez le saisir dans la case ci-dessous</p>
                <form action="<?php echo e(route('storeCoupon')); ?>" method="POST">
                  <?php echo csrf_field(); ?>
                  <div class="input-group mb-4 border rounded-pill p-2">
                    <input type="text" placeholder="Appliquer coupon" name="code" aria-describedby="button-addon3" class="form-control border-0">
                    <div class="input-group-append border-0">
                      <button id="button-addon3" type="submit" class="btn btn-dark px-4 rounded-pill"><i class="fa fa-gift mr-2"></i>Appliquer coupon</button>
                    </div>
                  </div>
                </form>
              </div>
              <?php else: ?>
              <div class="p-4">
                <p class="font-italic mb-4">Un coupon est déja appliqué</p>
              </div>
              <?php endif; ?>
              <div class="bg-light rounded-pill px-4 py-3 text-uppercase font-weight-bold">INSTRUCTIONS POUR LE VENDEUR</div>
              <div class="p-4">
                <p class="font-italic mb-4">Si vous avez des informations pour le vendeur, vous pouvez les laisser dans la case ci-dessous</p>
                <textarea name="" cols="30" rows="2" class="form-control"></textarea>
              </div>  
            </div>
            <div class="col-lg-6">
              <div class="bg-light rounded-pill px-4 py-3 text-uppercase font-weight-bold">RÉCAPITULATIF DE LA COMMANDE </div>
              <div class="p-4">
                <p class="font-italic mb-4">Les frais d'expédition et les frais supplémentaires sont calculés en fonction des valeurs que vous avez saisies.</p>
                <ul class="list-unstyled mb-4">
                  <li class="d-flex justify-content-between py-3 border-bottom"><strong class="text-muted">sous-total de la commande
                  </strong><strong><?php echo e(Cart :: SubTotal ()); ?>FCFA</strong></li>
                  <?php if(request()->session()->has('coupon')): ?>
                  <li class="d-flex justify-content-between py-3 border-bottom">
                    <strong class="text-muted">Coupon: <?php echo e(request()->session()->get('coupon')['code'] ?? ''); ?>

                      <form action="<?php echo e(route('destroyCoupon')); ?>" method="POST" class="d-inline-block">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-sm btn-outline-danger">
                          <i class="fa fa-trash-o fa-lg" style="color: red; "></i>
                        </button>

                      </form>
                    </strong>
                    <strong><?php echo e(request()->session()->get('coupon')['remise'] ?? 0); ?> FCFA</strong>
                  </li>

                  <li class="d-flex justify-content-between py-3 border-bottom"><strong class="text-muted">Nouveau sous-total
                  </strong><strong><?php echo e($newSubTotal); ?>FCFA</strong></li>

                  <li class="d-flex justify-content-between py-3 border-bottom"><strong class="text-muted">Frais de port et de manutention
                  </strong><strong><?php echo e($newTax); ?>FCFA</strong></li>

                  <li class="d-flex justify-content-between py-3 border-bottom"><strong class="text-muted">Total</strong>
                    <h5 class="font-weight-bold"><?php echo e($newTotal); ?>FCFA</h5>
                  </li>

                  <?php else: ?>
                  <li class="d-flex justify-content-between py-3 border-bottom"><strong class="text-muted">Frais de port et de manutention
                  </strong><strong><?php echo e(Cart :: tax ()); ?>FCFA</strong></li>

                  <li class="d-flex justify-content-between py-3 border-bottom"><strong class="text-muted">Total</strong>
                    <h5 class="font-weight-bold"><?php echo e(Cart::Total()); ?>FCFA</h5>
                  </li>
                  <?php endif; ?>

                </ul>
                <form action="<?php echo e(Route('paiemant.index')); ?>" method="GET">
                  <?php echo csrf_field(); ?>
                  <a href="<?php echo e(route('make.payment')); ?>" class="btn btn-primary mt-3">Pay $224 via Paypal</a>
                  <label for="" class="form-check-label">
                    <input type="radio" class="form-check-input" name="payment_method" value="Paypal">Paypal
                  </label>
                  <label for="" class="form-check-label">
                    <input type="radio" name="payment_method" value="Autre">Autre
                  </label>
                  <button type="submit" class="btn btn-dark rounded-pill py-2 btn-block mt-3">
                    Passer à la caisse
                  </button>
                </form>
              </div>
            </div>
          </div>
          <?php else: ?>
          <div class="aler alert-warning text-center p-3">
            <h1>Votre panier est vide.</h1>
          </div>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
  <?php $__env->stopSection(); ?>

  <?php $__env->startSection('extra-js'); ?>

  <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
  <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>

  


  <script>
   <?php if(Session::has('message')): ?>
   var type="<?php echo e(Session::get('alert-type','info')); ?>"

   switch(type){
     case 'info':
     toastr.info("<?php echo e(Session::get('message')); ?>");
     break;
     case 'success':
     toastr.success("<?php echo e(Session::get('message')); ?>");
     break;
     case 'warning':
     toastr.warning("<?php echo e(Session::get('message')); ?>");
     break;
     case 'error':
     toastr.error("<?php echo e(Session::get('message')); ?>");
     break;
   }
   <?php endif; ?>
 </script>
 <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.testLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sunuboutique\resources\views/cart/index.blade.php ENDPATH**/ ?>