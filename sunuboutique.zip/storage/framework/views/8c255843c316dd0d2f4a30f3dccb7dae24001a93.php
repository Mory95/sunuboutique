  <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        <h1 style="text-align: center;"><b>Bienvenue <?php echo e(Auth::user()->name); ?></b></h1>
     <?php $__env->endSlot(); ?>
    <div class="container row mt-5">
        <div class="col-md-4">
            <fieldset class="border p-2">
                <nav class="">
                    <ul>
                        <li class="">
                            <a href="#">Tableau de bord ></a>
                        </li>
                        <li class="">
                            <a href="#">Commandes ></a>
                        </li>
                        <li class="">
                            <a href="#">Téléchargements ></a>
                        </li>
                        <li class="">
                            <a href="#">Adresses ></a>
                        </li>
                        <li class="ccount">
                            <a href="#">Détails du compte ></a>
                        </li>
                        <li class="">
                            <a href="#">Déconnexion ></a>
                        </li>
                    </ul>
                </nav>
            </fieldset>
        </div>
        <div class="col-md-6 ml-5 border-2">
            <p>
                Bonjour <strong><?php echo e(Auth::user()->name); ?></strong>
            </p>

            <p>
                À partir du tableau de bord de votre compte, vous pouvez visualiser vos 
                <a href="#">
                    commandes récentes
                </a>, gérer vos <a href="#">adresses de livraison et de facturation</a> ainsi que <a href="#">changer votre mot de passe et les détails de votre compte</a>.
            </p>
        </div>
    </div>


   
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 

<?php /**PATH C:\xampp\htdocs\sunuboutique\resources\views/dashboard.blade.php ENDPATH**/ ?>