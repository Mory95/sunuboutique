
<?php $__env->startSection('extra-style'); ?>
<link href="<?php echo e(asset('css/orderStyle.css')); ?>" rel="stylesheet">
<link href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container row mt-5">
	<div class="col-md-4">
		
			<nav class="" style="text-align: center;">
				<ul>
					<li class="">
						<a href="#">Tableau de bord ></a>
					</li>
					<li class="">
						<a href="<?php echo e(route('mes-commandes')); ?>">Mes Commandes ></a>
					</li>
					<li class="active">
						<a href="#">Détails du compte ></a>
					</li>
					<li class="">
						<a href="#">Déconnexion ></a>
					</li>
				</ul>
			</nav>
		
	</div>
	<div class="col-md-6 ml-5"> 
		<!-- end sidebar -->
		<div class="my-profile">
			<div class="products-header">
				<h1 class="stylish-heading"><strong>Mon Profile</strong></h1>
			</div>

			<div>
				<div class="form-group">
					<form action="<?php echo e(route('mon-compte.update')); ?>" method="POST">
						<?php echo method_field('patch'); ?>
						<?php echo csrf_field(); ?>
						<div>
							<input id="name" class="form-control" type="text" name="name" value="<?php echo e(old('name', Auth::user()->name)); ?>" placeholder="Name" required>
						</div>

						<div class="mt-4">
							<input id="email" class="form-control" type="email" name="email" value="<?php echo e(old('email', Auth::user()->email)); ?>" placeholder="Email" required>
						</div>
						
						<div class="mt-4">
							<input class="form-control" id="password" type="password" name="password" placeholder="Password">
							<div class="mt-1">
								Laissez le champs(password) vide si vous voulez conserver l'ancien mot de passe
							</div>
						</div>

						<div class="mt-4">
							<input class="form-control" id="password-confirm" type="password" name="password_confirmation" placeholder="Confirm Password">
						</div>

						<div>
							<button type="submit" class="my-profile-button mt-3 btn btn-dark">
								Update Profile
							</button>
						</div>
					</form>
				</div>
		
	</div>
</div>
<?php $__env->stopSection(); ?>  
<?php $__env->startSection('extra-js'); ?>

<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
<script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>


<script>
	<?php if(Session::has('message')): ?>
	var type="<?php echo e(Session::get('alert-type','info')); ?>"

	switch(type){
		case 'info':
		toastr.info("<?php echo e(Session::get('message')); ?>");
		break;
		case 'success':
		toastr.success("<?php echo e(Session::get('message')); ?>");
		break;
		case 'warning':
		toastr.warning("<?php echo e(Session::get('message')); ?>");
		break;
		case 'error':
		toastr.error("<?php echo e(Session::get('message')); ?>");
		break;
	}
	<?php endif; ?>
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.testLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sunuboutique\resources\views/auth/profil.blade.php ENDPATH**/ ?>