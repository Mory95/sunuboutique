
<?php $__env->startSection('extra-style'); ?>
<link href="<?php echo e(asset('css/orderStyle.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container row mt-5">
	<div class="col-md-4">
		
			<nav class="" style="text-align: center;">
				<ul>
					<li>
						<a href="#">Tableau de bord ></a>
					</li>
					<li class="active">
						<a href="<?php echo e(route('mes-commandes')); ?>">Mes Commandes ></a>
					</li>
					<li class="">
						<a href="#">Détails du compte ></a>
					</li>
					<li class="">
						<a href="#">Déconnexion ></a>
					</li>
				</ul>
			</nav>
		
	</div>
	<div class="col-md-6"> 
		<!-- end sidebar -->
		<div class="my-profile">
			<div class="products-header">
				<h1 class="stylish-heading">Ma Commande N°<?php echo e($id_commande); ?></h1>
			</div>

			<div>
				<div>
					<?php $__currentLoopData = $commande; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $com): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="order-container border-2">
						<div class="flex border-2" style="background-color: #f4f5f7;">
							<div class="flex">
								<div>
									<div class="uppercase font-bold">Date commande</div>
									<div><?php echo e(Carbon\Carbon::parse($com->created_at)->format('M d, Y')); ?></div>
								</div>
								<div class="ml-3">
									<div class="uppercase font-bold">Id commande</div>
									<div><?php echo e(($com->id)); ?></div>
								</div>
								<div class="ml-3">
									<div class="uppercase font-bold">Total</div>
									<div><?php echo e(($com->montant_commande)); ?> FCFA</div>
								</div>
							</div>
							<div>
								<div class="flex ml-10">
									<div><a href="#">Facture</a></div>
								</div>
							</div>
						</div>
						<div>
							<?php $__currentLoopData = unserialize($com->produits.$compteur); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<ul>
								<li>Libelle: <?php echo e(($prod[$compteur])); ?></li>
								<li>Prix: <?php echo e(($prod[$compteur+1])); ?></li>
								<li>Quantité: <?php echo e(($prod[$compteur+2])); ?></li>
							</ul><br>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
				
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.testLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sunuboutique\resources\views/auth/ma-commande.blade.php ENDPATH**/ ?>