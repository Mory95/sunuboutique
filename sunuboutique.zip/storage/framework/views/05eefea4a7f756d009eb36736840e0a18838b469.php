<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo e(config('app.name', 'MyEcommerce')); ?></title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

    

    <!-- Styles -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldContent('extra-style'); ?>

    <!-- Script -->
    <?php echo $__env->yieldContent('extra-script'); ?>
</head>


<body class="antialiased">
    

    <nav wire:id="nPccJiAnIYX8LrUUSFLh" x-data="{ open: false }" class="bg-white border-b border-gray-100">
        <!-- Primary Navigation Menu -->
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <div class="flex">
                    <!-- Logo de notre entreprise -->

                    <!-- Navigation Links -->
                    <div class=" sm:-my-px sm:ml-10 sm:flex">
                        <a class="inline-flex items-center px-1 pt-1 border-b-2 border-indigo-400 text-sm font-medium leading-5 text-gray-900 focus:outline-none focus:border-indigo-700 transition duration-150 ease-in-out" href="/dashboard">
                            My-Ecommerce
                        </a>
                        <form class="navbar-form navbar-left ml-3 mt-3" action="/action_page.php">
                            <div class="input-group">
                                <input type="text" class="form-control" placeholder="Search">
                                <div class="input-group-btn">
                                    <button class="btn btn-primary" type="submit">
                                        <span class="glyphicon glyphicon-search"></span>Search
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Settings Dropdown -->
                
                <b class="mt-3 mr-20">
                    <a class="nav-link panier" href="<?php echo e(route('cart.index')); ?>" aria-label="Panier">
                    
                        <span>Panier</span>
                        <span class="badge badge-pill badge-dark"><?php echo e(Cart::Count()); ?></span>
                    </a>
                </b>
            </div>

            <!-- Responsive Navigation Menu -->
        </div>
    </nav>
    <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            
            <nav class="nav d-flex justify-content-between">
                <?php $__currentLoopData = DB::table('categories')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="p-2 text-muted" name="qr" href="#<?php echo e(route('produit.index', ['categorie' =>$cat->slug] )); ?>">
                    <?php echo e($cat->name); ?>

                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </nav>
                            
                        </h2>
                    </div>

                    
                    <?php echo $__env->yieldContent('content'); ?>
                    <?php echo $__env->yieldContent('extra-js'); ?>
                </body>
                </html>
<?php /**PATH C:\xampp\htdocs\sunuboutique\resources\views/layouts/masterLayout.blade.php ENDPATH**/ ?>